def find_words(Book1.txt):
	with open(Book1.txt, "r",encoding="20k.txt") as current_file:
		text=current_file.read()
		text=text.replace("\n","").replace("\r","")
	return text

def find_words(Book2.txt):
        with open(Book2.txt, "r",encoding="20k.txt") as current_file:
                text=current_file.read()
                text=text.replace("\n","").replace("\r","")
        return text

def find_words(Book3.txt):
        with open(Book1.txt, "r",encoding="20k.txt") as current_file:
                text=current_file.read()
                text=text.replace("\n","").replace("\r","")
        return text

