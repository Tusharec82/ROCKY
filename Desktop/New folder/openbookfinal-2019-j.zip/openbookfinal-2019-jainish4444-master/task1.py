import shutil

shutil.copyfile('/home/student/finallab/openbookfinal-2019-jainish4444/abc.txt', '/home/student/finallab/openbookfinal-2019-jainish4444/abc_copy2.txt')


print("File Copy Done")
